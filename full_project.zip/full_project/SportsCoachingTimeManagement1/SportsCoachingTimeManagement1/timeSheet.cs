﻿using System.Collections.Generic;

namespace SportsCoachingTimeManagement1
{
    public static class timeSheet
    {
        public static List<Course> Courses = new List<Course>();
    }
}
